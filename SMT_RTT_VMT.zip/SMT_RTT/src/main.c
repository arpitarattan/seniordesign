#include "stm32f0xx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h> // for memmove()








void mysleep(int time) {
    for(int n = 0; n < time; n++);
}
// VMT Interupt
void EXTI0_1_IRQHandler() {
    while(readpinB(1) == 0); //PB1 - VMT
    EXTI->PR |= EXTI_PR_PR1;
    setup_vmt();

    EXTI->PR &= ~EXTI_PR_PR1;

}
void EXTI2_3_IRQHandler() {
    inita();
    initb();
    initc();
    init_tim2();


    while(readpinA(3) == 0); //PA3 - RTT
    EXTI->PR |= EXTI_PR_PR3;
    setnA(0,1); //turn on green led //pa0
    setnA(1,1); //turn on red led
    start_timer();
    rtt();
    EXTI->PR &= ~EXTI_PR_PR3;
}
void EXTI4_15_IRQHandler() {
    while(readpinA(6) == 0); //PA6 - SMT
    EXTI->PR |= EXTI_PR_PR6;
    setup_SMT();

    EXTI->PR &= ~EXTI_PR_PR6;
}

void init_exti(){
    RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;
    SYSCFG->EXTICR[0] |= SYSCFG_EXTICR1_EXTI1_PB;
    SYSCFG->EXTICR[0] |= SYSCFG_EXTICR1_EXTI3_PA;
    SYSCFG->EXTICR[1] |= SYSCFG_EXTICR2_EXTI6_PA;

    EXTI->IMR |= EXTI_IMR_MR1; //exti_imr configures the corresponding the mask bit
    EXTI->IMR |= EXTI_IMR_MR3; //exti_imr configures the corresponding the mask bit
    EXTI->IMR |= EXTI_IMR_MR6; //exti_imr configures the corresponding the mask bit
    EXTI->RTSR |= EXTI_RTSR_TR1; //enable rising trigger selection register (button press)
    EXTI->RTSR |= EXTI_RTSR_TR3; //enable rising trigger selection register (button press)
    EXTI->RTSR |= EXTI_RTSR_TR6; //enable rising trigger selection register (button press)
    EXTI->FTSR &= ~EXTI_FTSR_TR1; // disable Trigger on falling edge
    EXTI->FTSR &= ~EXTI_FTSR_TR3; // disable Trigger on falling edge
    EXTI->FTSR &= ~EXTI_FTSR_TR6; // disable Trigger on falling edge

    NVIC_EnableIRQ(EXTI0_1_IRQn);
    NVIC_SetPriority(EXTI0_1_IRQn,2);
    NVIC_EnableIRQ(EXTI2_3_IRQn);
    NVIC_SetPriority(EXTI2_3_IRQn,2);
    NVIC_EnableIRQ(EXTI4_15_IRQn);
    NVIC_SetPriority(EXTI4_15_IRQn,2);
    print_string("        ", 0);
}


//===========================================================================
// Main function
//===========================================================================

int main(void) {
    //-------v--THINGS FOR SSD--v-------//
        init_tim7();
        setup_bb();
        init_spi2();
        setup_dma();
        enable_dma();
        init_tim15();
    //-------^--THINGS FOR SSD--^-------//
        GPIOB->BSRR = GPIO_BSRR_BS_0;


    inita();
    initb();
    init_exti();

}
