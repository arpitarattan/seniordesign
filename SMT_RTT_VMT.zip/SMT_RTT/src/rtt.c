#include "stm32f0xx.h"
#include <string.h> // for memmove()
#include <stdio.h>
#include <stdlib.h> // for srandom() and random()

void inita();
void initb();
void initc();
void init_tim2();
void setnA(int32_t pin_num, int32_t val);
void setnB(int32_t pin_num, int32_t val);
void setnC(int32_t pin_num, int32_t val);
int32_t readpinB(int32_t pin_num);
int32_t readpinA(int32_t pin_num);
void rtt();
void start_timer();
uint32_t end_timer();



volatile int milliseconds = 0; //global variable to count the milliseconds
volatile int input_delay = 0; //global variable to control the delay length
volatile int delay_completed = 0; //global variable to stop the interrupt and timer
volatile int press_too_early = 0; //global variable to see if the user pressed the button to early
volatile uint32_t new_seed = 0;

// --------------------v--RTT--v----------------------//

void TIM2_IRQHandler(void) {
    TIM2->SR &= ~TIM_SR_UIF;
}
void init_tim2() {
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
    TIM2->DIER |= TIM_DIER_UIE; //enable the timer update interrupt
    TIM2->PSC = 48000 - 1;
    TIM2->ARR = 10000 - 1;
    TIM2->CR1 &= ~TIM_CR1_DIR;

    //where to set priority
}

void start_timer() {
    TIM2->CNT = 0;
    TIM2->CR1 |= TIM_CR1_CEN;
    NVIC_EnableIRQ(TIM2_IRQn);
    NVIC_SetPriority(TIM2_IRQn,1);
}
uint32_t end_timer() {
    TIM2->CR1 &= ~TIM_CR1_CEN;

    uint32_t time = TIM2->CNT;
    TIM2->CNT = 0;
    NVIC_DisableIRQ(TIM2_IRQn);
    return time;
}
void init_tim14() {
    RCC->APB1ENR |= RCC_APB1ENR_TIM14EN;
    TIM14->DIER |= TIM_DIER_UIE; //enable the timer update interrupt
    TIM14->PSC = 48 - 1;
    TIM14->ARR = 1000 - 1;
    TIM14->CR1 |= TIM_CR1_DIR; //want the timer to count up

    TIM14->CR1 |= TIM_CR1_CEN;

}
void TIM14_IRQHandler(void) {
    int ms = 0;
    while(!delay_completed) {
        if(readpinA(2) == 1) {
            press_too_early = 1;
            TIM14->CR1 &= ~TIM_CR1_CEN;
            delay_completed = 1;
            return;
        }
        if((TIM14->SR & TIM_SR_UIF) != 0) {
            TIM14 ->SR &= ~TIM_SR_UIF;
            milliseconds++;
            ms = milliseconds;
            if(milliseconds == input_delay) {
                TIM14->CR1 &= ~TIM_CR1_CEN;
                delay_completed = 1;
                break;
            }
        }
    }
}
void TIM14_Delay(int ms) {
    input_delay = ms-500;
    NVIC_EnableIRQ(TIM14_IRQn);
    NVIC_SetPriority(TIM14_IRQn,1);
    if(delay_completed == 1) {
        NVIC_DisableIRQ(TIM14_IRQn);
        input_delay = 0;
        delay_completed = 0;
        milliseconds = 0;
    }
}

uint32_t standard_reaction_time_test(int test_num) {

    init_tim14();
    //pa0 -green LED
    //pa1 - red LEd
    //pa2 - button
    while(readpinA(2) == 0); //user needs to press button to start game //pa2
    mysleep(1000000);
    print_string("        ", 0);

    if(test_num == 0){
        new_seed = end_timer();
        srand(new_seed);
    }
    else{
        srand(new_seed + test_num);
    }
//    uint32_t new_seed = end_timer();
    //uint32_t num = 100000+ rand() % (9999999 - 100000);
    uint32_t num = 3000+ rand() % (7000 - 3000);
    mysleep(100000);

    setnA(0,0);
    setnA(1,0);

    setnA(1,1);              //turn the red led light on

   // mysleep(3000000);             //a min amount of time
    //mysleep(num*480);
    TIM14_Delay(num);
    setnA(0,1);                //turn the green led on
    setnA(1,0);               //turn the red led off
    if(press_too_early == 1) {
        setnA(0,0);
        press_too_early = 0;
        print_string("ERR     ", 0);
        return 0;
    }
    start_timer();
    while(readpinA(2) == 0); //wait for user to press button
    setnA(0,0);                //turn off green led
    setnA(1,0);
    uint32_t reaction_time = end_timer();

    mysleep(1000000);            //wait
    return reaction_time;
}
uint32_t unit_test1() {
    //press button start timer
    //press button end timer
    end_timer();
    setnA(1,0);
    setnA(0,0);
    while(readpinA(2) == 0);
    mysleep(1000000);
    setnA(1,1);
    start_timer();
    while(readpinA(2) == 0);
    mysleep(1000000);
    setnA(1,0);
    uint32_t time = end_timer();

    return time;
}
void int_to_char(int x)
{
    char string[9] = "        ";
//    x = x / 10;
    string[3] = x%10 + '0';
    x = x / 10;
    string[2] = x%10 + '0';
    x = x / 10;
    string[1] = x%10 + '0';
    x = x / 10;
    string[0] = x%10 + '0';

    print_string(string, 1);
}
void rtt()
{
    init_tim14();
    int i = 0;
    int sum = 0;
    while( i < 3) {
        uint32_t reaction_time = standard_reaction_time_test(i);
//        uint32_t time = unit_test1();
        mysleep(1000000);
        if(reaction_time != 0){
            sum += reaction_time;
            int_to_char(reaction_time);
            i++;
        }
    }
    sum = sum/3;
    mysleep(1000000);
    print_string("0000    ",0);
    mysleep(1000000);
    int_to_char(sum);
}


void inita() {
    //inputs PA3 (RTT select), PA6 (SMT select), PA2 (RTT button)
    //outputs (PA0, PA1)
    RCC -> AHBENR |= RCC_AHBENR_GPIOAEN;

    GPIOA -> MODER &= ~GPIO_MODER_MODER3; //pa3
    GPIOA-> PUPDR  &= ~GPIO_PUPDR_PUPDR3;
    GPIOA-> PUPDR |= GPIO_PUPDR_PUPDR3_1;

    GPIOA -> MODER &= ~GPIO_MODER_MODER6; //pa6
    GPIOA-> PUPDR  &= ~GPIO_PUPDR_PUPDR6;
    GPIOA-> PUPDR |= GPIO_PUPDR_PUPDR6_1;

    GPIOA -> MODER &= ~GPIO_MODER_MODER2; //pa2
    GPIOA-> PUPDR  &= ~GPIO_PUPDR_PUPDR2;
    GPIOA-> PUPDR |= GPIO_PUPDR_PUPDR2_1;

    //outputs
    GPIOA -> MODER &= ~GPIO_MODER_MODER0; //pa0
    GPIOA -> MODER |= GPIO_MODER_MODER0_0;
    GPIOA -> MODER &= ~GPIO_MODER_MODER0_1;

    GPIOA -> MODER &= ~GPIO_MODER_MODER1; //pa1
    GPIOA -> MODER |= GPIO_MODER_MODER1_0;
    GPIOA -> MODER &= ~GPIO_MODER_MODER1_1;
}
void initb() {
   RCC -> AHBENR |= RCC_AHBENR_GPIOBEN;
   GPIOB -> MODER &= ~GPIO_MODER_MODER1;
   GPIOB-> PUPDR  &= ~GPIO_PUPDR_PUPDR1;
   GPIOB-> PUPDR |= GPIO_PUPDR_PUPDR1_1;
   GPIOB -> MODER &= ~(GPIO_MODER_MODER0);
   GPIOB -> MODER |= GPIO_MODER_MODER0_0;


   //output PB0 - Green LED
   GPIOB -> MODER &= ~GPIO_MODER_MODER0;
   GPIOB -> MODER |= GPIO_MODER_MODER0_0;
   GPIOB -> MODER &= ~GPIO_MODER_MODER0_1;
}
void initc() {
   RCC -> AHBENR |= RCC_AHBENR_GPIOCEN;
   //output PC0 - Yellow LED
   GPIOC -> MODER &= ~GPIO_MODER_MODER0;
   GPIOC -> MODER |= GPIO_MODER_MODER0_0;
   GPIOC -> MODER &= ~GPIO_MODER_MODER0_1;
}

void setnA(int32_t pin_num, int32_t val) {
    if(val == 0){

        GPIOA -> BRR |= 1 << pin_num;
    }
    else{
        GPIOA -> BSRR |= 1 << pin_num;

    }
}

void setnB(int32_t pin_num, int32_t val) {
    if(val == 0){

        GPIOB -> BRR |= 1 << pin_num;
    }
    else{
        GPIOB -> BSRR |= 1 << pin_num;

    }
}
void setnC(int32_t pin_num, int32_t val) {
    if(val == 0){

        GPIOC -> BRR |= 1 << pin_num;
    }
    else{
        GPIOC -> BSRR |= 1 << pin_num;

    }
}

int32_t readpinA(int32_t pin_num) {
    int32_t readit = 0;
    readit = (GPIOA -> IDR);
    //readit = (GPIOB -> IDR) & 0x1;

    readit = (readit & (1 << pin_num)) >> pin_num;

    return readit;
}

int32_t readpinB(int32_t pin_num) {
    int32_t readit = 0;
    readit = (GPIOB -> IDR);
    //readit = (GPIOB -> IDR) & 0x1;

    readit = (readit & (1 << pin_num)) >> pin_num;

    return readit;
}

// ------------------^--RTT--^--------------------//
